# from django.forms import Form

# class homeform(forms.Form):
#     School=forms.CharField( max_length=100, required=False)
#     Village=forms.CharField( max_length=100, required=False)