from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.response import Response
from .models import customer
from .serializers import customerserializer,masterserializer
from rest_framework.decorators import api_view
from .models import customer,master
from django.core import serializers
import json
# import crypt
from django.contrib.auth.hashers import make_password
# from .forms import homeform
# To encrypt the password. This creates a password hash with a random salt.

# Create your views here.
def homeview(request):
    # hh=master.objects.all()
    # hh.delete()
    cx=''
    if(request.method=='POST'):
        o=request.POST
        n=o.get('name')
        p=o.get('password')
        password_hash=make_password(p)
        # password_hash = crypt.crypt(p)
        z=master.objects.all()
        outt=serializers.serialize('json',z)
        val=json.loads(outt)
        coun=0
        # cx=''
        for i in val:
            if(i.get('fields')['name']==n):
                coun=1
                if(coun==1):
                    break;
        


        # for i in outt:
        #     print(['fields']['name'])
        print(z,n,p)
        # print(master.objects.all())
        if(coun==0):
            x=master.objects.create(name=n,password=password_hash)
            x.save()
            hout='<h1> Welcome to Healthkart '+n.upper()+'!</h1>'
            # homeform()
            return render(request,'home.html')
        else:
            cx='User Exists'
        # else:
        #     cx='User Already exists'

    # @apiview(['GET'])
    # # c=customer(1,'Dhileep',20,'usg')
    # # c.save()
    # # print(_())
    return render(request,'login.html',{'err_msg':cx})
@api_view(['GET'])
def information(request):
    s=master.objects.all()
    p=masterserializer(s,many=True)
    # k=json.dumps(p)
    return Response(p.data)
    

