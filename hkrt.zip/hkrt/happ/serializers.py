from rest_framework import serializers
from .models import customer,master

class customerserializer(serializers.ModelSerializer):
    class Meta:
        model=customer
        fields=('id','name','age','password')

class masterserializer(serializers.ModelSerializer):
    class Meta:
        model=master
        fields=('id','name','password')