from django.contrib import admin
from.models import customer,master
admin.site.register(customer)
admin.site.register(master)
# Register your models here.
